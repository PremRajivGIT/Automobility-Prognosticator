Firstly, you will be able to see 4 files other than this "README.txt". In which one is "main.ipynb" that can only be run through jupyter notebook.

Steps to install jupyter notebook:
1) Make sure you have python installed in your system. The version of python must be >= 8
2) Then open your terminal/cmd and enter "pip3 install jupyter"

Steps to run the script:
1) Navigate to the place where the script is residing
2) Open terminal/cmd there
3) Execute the command "pip3 install -r requirements.txt" or "python -m pip install -r requirements.txt"
4) Then type the command "jupyter notebook"
5) Make sure that you have the files "usecase_1_.csv" and "eligibilities.txt" are in the same directory as the code file is.
6) Now run the cells one by one.
7) The last cell will take a while to run depending on the hardware configuration of the system.

*Note that we executed this code on Kaggle*
1) To do it on Kaggle, first create an account and create a new code file.
2) Then type the command "!pip3 install numpy pandas scikit-learn xgboost optuna"
3) After that paste in the code you can see in main.ipynb
4) Connect to an environment, select the hardware option (depending on the plans that you are using).
5) Then upload the files "usecase_1_.csv" and "eligibilities.txt" to Kaggle under add input field and give it a name.
6) After uploading completes, make sure to change the variables:

TRIALS_PATH = "/kaggle/input/your_dataset_name/usecase_1_.csv"
ELIGIBILITIES_PATH = "/kaggle/input/your_dataset_name/eligibilities.txt"

7) Then run the cells in order.